class Book:
    def __init__(self, title, author, category, isbn):
        self.title = title
        self.author = author
        self.category = category
        self.isbn = isbn

    def __repr__(self):
        return f"Book(title={self.title}, author={self.author}, category={self.category}, isbn={self.isbn})"

class Member:
    def __init__(self, name, member_id, contact_info):
        self.name = name
        self.member_id = member_id
        self.contact_info = contact_info

    def __repr__(self):
        return f"Member(name={self.name}, member_id={self.member_id}, contact_info={self.contact_info})"

# Sample data
books = [
    Book("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", "9780743273565"),
    Book("1984", "George Orwell", "Dystopian", "9780451524935"),
    Book("To Kill a Mockingbird", "Harper Lee", "Fiction", "9780061120084"),
    Book("The Catcher in the Rye", "J.D. Salinger", "Fiction", "9780316769488")
]

members = [
    Member("Alice Smith", "001", "alice@example.com"),
    Member("Bob Johnson", "002", "bob@example.com"),
    Member("Charlie Brown", "003", "charlie@example.com")
]

# Search functions
def search_books_by_title(title, books):
    return [book for book in books if title.lower() in book.title.lower()]

def search_books_by_author(author, books):
    return [book for book in books if author.lower() in book.author.lower()]

def search_books_by_category(category, books):
    return [book for book in books if category.lower() in book.category.lower()]

def search_books_by_isbn(isbn, books):
    return [book for book in books if isbn == book.isbn]

def search_members_by_name(name, members):
    return [member for member in members if name.lower() in member.name.lower()]

def search_members_by_id(member_id, members):
    return [member for member in members if member_id == member.member_id]

def search_members_by_contact_info(contact_info, members):
    return [member for member in members if contact_info.lower() in member.contact_info.lower()]

# Example usage
print("Search Books by Title '1984':", search_books_by_title("1984", books))
print("Search Books by Author 'George Orwell':", search_books_by_author("George Orwell", books))
print("Search Books by Category 'Fiction':", search_books_by_category("Fiction", books))
print("Search Books by ISBN '9780316769488':", search_books_by_isbn("9780316769488", books))

print("Search Members by Name 'Alice':", search_members_by_name("Alice", members))
print("Search Members by ID '002':", search_members_by_id("002", members))
print("Search Members by Contact Info 'charlie@example.com':", search_members_by_contact_info("charlie@example.com", members))
